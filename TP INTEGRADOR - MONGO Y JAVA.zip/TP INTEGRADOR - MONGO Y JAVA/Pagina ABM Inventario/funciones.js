function ingresoProducto() {
    //obtiene los datos que el user pasa por el forms 
    var nombreIngresado = document.getElementById("nombre").value;
    var descripcionIngresada = document.getElementById("descripcion").value;
    var categoriaIngresada = document.getElementById("categoria").value;
    var precioDeCompraIngresado = document.getElementById("precioCompra").value;
    var precioDeVentaIngresado = document.getElementById("precioVenta").value;
    var stockIngresado = document.getElementById("stock").value;
    var stockDeReposicionIngresado = document.getElementById("stockReposicion").value;
    var nombreProveedorIngresado = document.getElementById("nombreProveedor").value;

    let objetoConInformacion = {nombre:nombreIngresado,descripcion:descripcionIngresada,categoria:categoriaIngresada,precioCompra:precioDeCompraIngresado,precioVenta:precioDeVentaIngresado,stock:stockIngresado,stockDeReposicion:stockDeReposicionIngresado,nombreProveedor:nombreProveedorIngresado};

    $.ajax({
        url: "http://localhost:8080/api/datos/productos/",
        type: 'POST',
        contentType: "application/json",
        data: JSON.stringify(objetoConInformacion)
    })
    .done(function (data) {

        alert("Datos ingresados con éxito!");

    })
    .fail(function (jqXHR, textStatus, errorThrown) {
        console.log("error, no se pudo ingresar los nuevos datos");
        console.log(jqXHR);
        console.log(textStatus);
        console.log(errorThrown);
    });
}

function editarProducto() {
    //obtiene los datos que el user pasa por el forms
    var idIngresada = $("#idProductoModificar").val();
    var campo = verificarProducto();
    var valor = $("#valorAModificar").val();
    console.log(campo);

    let objetoConActualizacion = {campo : campo,nuevoValor : valor};

    $.ajax({
        url: "http://localhost:8080/api/datos/productos/" + idIngresada,
        type: 'PATCH',
        contentType: "applicatialumnosn",
        data: JSON.stringify(objetoConActualizacion)
    })
    .done(function (data) {

        alert("Producto modificado!");

    })
    .fail(function (jqXHR, textStatus, errorThrown) {
        console.log("error, no se pudo ingresar los nuevos datos");
        console.log(jqXHR);
        console.log(textStatus);
        console.log(errorThrown);
    });
}

function borrarProducto(){
    var id = $("#idABorrar").val();

    var url = "http://localhost:8080/api/datos/productos/" + id;

    $.ajax({
        url: url,
        type: 'DELETE',
    })
    .done(function (data) {

        alert("El producto fue borrado con éxito")

    })
    .fail(function (jqXHR, textStatus, errorThrown) {
        console.log("error, no se pudo ingresar los nuevos datos");
        console.log(jqXHR);
        console.log(textStatus);
        console.log(errorThrown);
    });
}

function verificarProducto() {
    var campo = "";
    let valores = document.getElementsByName("check");
    for(var i = 0;i < valores.length;i++){
        if(valores[i].checked){
            var valor = valores[i].value;
            if(valor == 1){
                campo = "nombre";
            }
            else if(valor == 2){
                campo = "descripcion";
            }
            else if(valor == 3){
                campo = "categoria";
            }
            else if(valor == 4){
                campo = "precioCompra";
            }
            else if(valor == 5){
                campo = "precioVenta";
            }
            else if(valor == 6){
                campo = "stock";
            }
            else if(valor == 7){
                campo = "stockDeReposicion";
            }
            else if(valor == 8){
                campo = "nombreDelProveedor";
            }
        }
    }
    return campo;
}

function buscarProducto() {
    var nombreIngresado = $("#idProductoABuscar").val();
    $.ajax({
        url: "http://localhost:8080/api/datos/productos/" + nombreIngresado,
        type: 'GET'
    })
    .done(function (data) {
        console.log(data.nombre)

        alert("Datos producto" + "\n" + 
        "Nombre: " + data.nombre + "\n" +
        "Descripcion: " + data.descripcion + "\n" +
        "Categoria: " + data.categoria + "\n" +
        "PrecioCompra: " + data.precioCompra + "\n" +
        "PrecioVenta: " + data.precioVenta + "\n" +
        "Stock: " + data.stock + "\n" +
        "StockReposicion: " + data.stockMinimo + "\n" +
        "NombreProveedor: " + data.nombreProveedor + "\n");
    
    })
    .fail(function (jqXHR, textStatus, errorThrown) {
        console.log("error, no se pudo obtener datos");
        console.log(jqXHR);
        console.log(textStatus);
        console.log(errorThrown);
    });
}

//-------------------------------------------------------------------------------------------------------------------------------

function ingresoProveedor() {
    //obtiene los datos que el user pasa por el forms 
    var nombreIngresado = document.getElementById("nombreProveedor").value;
    var paisIngresado = document.getElementById("paisProveedor").value;
    var ciudadIngresada = document.getElementById("ciudadProveedor").value;
    var direccionIngresada = document.getElementById("direccionProveedor").value;
    var contactoIngresado = document.getElementById("contactoProveedor").value;

    let objetoConInformacion = {nombre:nombreIngresado,ubicacion:{paisIngresado,ciudadIngresada,direccionIngresada},contacto:contactoIngresado};

    $.ajax({
        url: "http://localhost:8080/api/datos/proveedores",
        type: 'POST',
        contentType: "application/json",
        data: JSON.stringify(objetoConInformacion)
    })
    .done(function (data) {

        alert("Datos ingresados con éxito!");

    })
    .fail(function (jqXHR, textStatus, errorThrown) {
        console.log("error, no se pudo ingresar los nuevos datos");
        console.log(jqXHR);
        console.log(textStatus);
        console.log(errorThrown);
    });
}

function editarProveedor() {
    //obtiene los datos que el user pasa por el forms
    var idIngresada = $("#idProveedorAModificar").val();
    var campo = verificarProveedor();
    var valor = $("#valorAModificar").val();
    console.log(campo);

    let objetoConActualizacion = {campo : campo,nuevoValor : valor};

    $.ajax({
        url: "http://localhost:8080/api/datos/proveedores/" + idIngresada,
        type: 'PATCH',
        contentType: "application/json",
        data: JSON.stringify(objetoConActualizacion)
    })
    .done(function (data) {

        alert("Alumno modificado!");

    })
    .fail(function (jqXHR, textStatus, errorThrown) {
        console.log("error, no se pudo ingresar los nuevos datos");
        console.log(jqXHR);
        console.log(textStatus);
        console.log(errorThrown);
    });
}

function borrarProveedor(){
    var id = $("#idProveedorABorrar").val();

    var url = "http://localhost:8080/api/datos/proveedores/" + id;

    

    $.ajax({
        url: url,
        type: 'DELETE',
    })
    .done(function (data) {

        alert("El proveedor fue borrado con éxito")

    })
    .fail(function (jqXHR, textStatus, errorThrown) {
        console.log("error, no se pudo ingresar los nuevos datos");
        console.log(jqXHR);
        console.log(textStatus);
        console.log(errorThrown);
    });
}

function verificarProveedor() {
    var campo = "";
    let valores = document.getElementsByName("check");
    for(var i = 0;i < valores.length;i++){
        if(valores[i].checked){
            var valor = valores[i].value;
            if(valor == 1){
                campo = "nombreProveedor";
            }
            else if(valor == 2){
                campo = "paisProveedor";
            }
            else if(valor == 3){
                campo = "ciudadProveedor";
            }
            else if(valor == 4){
                campo = "ubicacionProveedor";
            }
            else if(valor == 5){
                campo = "contactoProveedor";
            }
        }
    }
    return campo;
}

function buscarProveedor() {
    var idIngresada = $("#idProveedorABuscar").val();
    $.ajax({
        url: "http://localhost:8080/api/datos/proveedores/" + idIngresada,
        type: 'GET'
    })
    .done(function (data) {

        alert("Datos alumno" + "\n" + 
        "Id: " + idIngresada + "\n" + 
        "Nombre: " + data.nombreProveedor + "\n" +
        "Pais: " + data.paisProveedor + "\n" +
        "Ciudad: " + data.ciudadProveedor + "\n" +
        "Direccion: " + data.direccionProveedor + "\n" +
        "Contacto: " + data.contactoProveedor + "\n");
    
    })
    .fail(function (jqXHR, textStatus, errorThrown) {
        console.log("error, no se pudo obtener datos");
        console.log(jqXHR);
        console.log(textStatus);
        console.log(errorThrown);
    });
}

function buscarTodosLosProveedores() {
    $.ajax({
        url: "http://localhost:8080/api/datos/proveedores/",
        type: 'GET'
    })
    .done(function (data) {

        alert(data);

    })
    .fail(function (jqXHR, textStatus, errorThrown) {
        console.log("error, no se pudo obtener datos");
        console.log(jqXHR);
        console.log(textStatus);
        console.log(errorThrown);
    });
}

//-------------------------------------------------------------------------------------------------------------------------------

function ingresoCompra() {
    //obtiene los datos que el user pasa por el forms 
    var idIngresada = document.getElementById("idCompra").value;
    var nombreIngresado = document.getElementById("nombreProductoCompra").value;
    var cantidadIngresada = document.getElementById("cantidadProductoCompra").value;
    var precioDeCompraIngresado = document.getElementById("precioDeCompraProductoCompra").value;
    var nombreDelProveedorIngresado = document.getElementById("nombreProveedorProductoCompra").value;
    var precioTotalIngresado = document.getElementById("precioTotalProductoCompra").value;

    let objetoConInformacion = {id:idIngresada,nombre:nombreIngresado,ubicacion:{paisIngresado,ciudadIngresada,direccionIngresada},contacto:contactoIngresado};

    $.ajax({
        url: "http://localhost:8080/api/datos/compras",
        type: 'POST',
        contentType: "application/json",
        data: JSON.stringify(objetoConInformacion)
    })
    .done(function (data) {

        alert("Datos ingresados con éxito!");

    })
    .fail(function (jqXHR, textStatus, errorThrown) {
        console.log("error, no se pudo ingresar los nuevos datos");
        console.log(jqXHR);
        console.log(textStatus);
        console.log(errorThrown);
    });
}

function buscarCompra() {
    var idIngresada = $("#idCompraABuscar").val();
    $.ajax({
        url: "http://localhost:8080/api/datos/compras/" + idIngresada,
        type: 'GET'
    })
    .done(function (data) {

        alert("Datos compra" + "\n" + 
        "Id: " + idIngresada + "\n" + 
        "Nombre: " + data.nombreProductoCompra + "\n" +
        "Cantidad: " + data.cantidadProductoCompra + "\n" +
        "PrecioDeCompra: " + data.precioCompraProductoCompra + "\n" +
        "nombreDelProveedor: " + data.nombreProveedorProductoCompra + "\n" +
        "precioTotal: " + data.precioTotalProductoCompra + "\n");
    
    })
    .fail(function (jqXHR, textStatus, errorThrown) {
        console.log("error, no se pudo obtener datos");
        console.log(jqXHR);
        console.log(textStatus);
        console.log(errorThrown);
    });
}

function buscarTodosLosProveedores() {
    $.ajax({
        url: "http://localhost:8080/api/datos/compras/",
        type: 'GET'
    })
    .done(function (data) {

        alert(data);

    })
    .fail(function (jqXHR, textStatus, errorThrown) {
        console.log("error, no se pudo obtener datos");
        console.log(jqXHR);
        console.log(textStatus);
        console.log(errorThrown);
    });
}