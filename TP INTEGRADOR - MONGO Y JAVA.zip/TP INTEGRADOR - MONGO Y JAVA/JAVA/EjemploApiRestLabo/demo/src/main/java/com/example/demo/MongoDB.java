package com.example.demo;

import com.mongodb.MongoClient;
import com.mongodb.client.*;
import org.bson.Document;
import org.springframework.stereotype.Service;
import java.util.*;

@Service
class MongoDB {
    private MongoDatabase baseDeDatos;
    private MongoCollection coleccion;

    public MongoDB(){
        this.conectar("inventario","producto");
    }

    public MongoDB(String coleccion) {
        this.conectar("inventario",coleccion);
    }

    public void conectar(String baseDeDatos,String coleccion){
        this.conectarABaseDeDatos(baseDeDatos);
        this.conectarAColeccion(coleccion);
    }

    public MongoDatabase getBaseDeDatos() {
        return baseDeDatos;
    }

    public void setBaseDeDatos(MongoDatabase baseDeDatos) {
        this.baseDeDatos = baseDeDatos;
    }

    public MongoCollection getColeccion() {
        return coleccion;
    }

    public void setColeccion(MongoCollection coleccion) {
        this.coleccion = coleccion;
    }

    public void conectarABaseDeDatos(String nombreBaseDeDatos){
        MongoClient mongo = new MongoClient("localhost",27017);
        this.baseDeDatos = mongo.getDatabase(nombreBaseDeDatos);
    }

    public void conectarAColeccion(String nombreDeColeccion){
        if (this.existeLaColeccion(nombreDeColeccion)){
            this.coleccion = baseDeDatos.getCollection(nombreDeColeccion);
        } else {
            baseDeDatos.createCollection(nombreDeColeccion);
            this.coleccion = baseDeDatos.getCollection(nombreDeColeccion);
        }
    }

    public boolean existeLaColeccion(String nombreDeColeccion){

        MongoIterable<String> nombresDeColecciones = baseDeDatos.listCollectionNames();
        boolean existe = false;

        for (String nombre : nombresDeColecciones) {
            if (nombre.equals(nombreDeColeccion)){
                existe = true;
            }
        }
        return existe;
    }


    //////////////////////////////////////////////////////////////////////
    //////////////////////////////////////////////////////////////////////
    //////////////////////////////////////////////////////////////////////
    //////////////////////////////////////////////////////////////////////
    //////////////////////////////////////////////////////////////////////
    //METODOS NUEVOS
    //////////////////////////////////////////////////////////////////////
    //////////////////////////////////////////////////////////////////////
    //////////////////////////////////////////////////////////////////////
    //////////////////////////////////////////////////////////////////////
    //////////////////////////////////////////////////////////////////////

    public HashMap<String,Object> obtenerDatosProducto(){
        HashMap<String,Object> datos = new HashMap<>();
        ArrayList<Producto> productos = new ArrayList<>();

        FindIterable resultado = coleccion.find();
        MongoCursor iterador = resultado.iterator();

        while (iterador.hasNext()) {
            Document documento = (Document) iterador.next();
            String nombre = documento.getString("nombre");
            String desc = documento.getString("descripcion");
            String categoria = documento.getString("categoria");
            double precioCompra = documento.getDouble("precioCompra");
            double precioVenta = documento.getDouble("precioVenta");
            int stock = documento.getInteger("stock");
            int stockMinimo = documento.getInteger("stockReposicion");
            String nombreProveedor = documento.getString("nombreProveedor");

            Producto producto = new Producto(nombre,desc,categoria,precioCompra,precioVenta,stock,stockMinimo,nombreProveedor);

            productos.add(producto);

            System.out.println(nombre + " - " + desc);
        }

        datos.put("productos",productos);
        return datos;
    }

    public HashMap<String,Object> obtenerDatosProveedores(){
        HashMap<String,Object> datos = new HashMap<>();
        ArrayList<Proveedor> proveedores = new ArrayList<>();

        FindIterable resultado = coleccion.find();
        MongoCursor iterador = resultado.iterator();

        while (iterador.hasNext()) {
            Document documento = (Document) iterador.next();
            Document ubicacion = (Document) documento.get("ubicacion");
            String nombre = documento.getString("nombre");
            int contacto = documento.getInteger("contacto");
            Ubicacion ubicacion1 = new Ubicacion(ubicacion.getString("pais"), ubicacion.getString("ciudad"),ubicacion.getString("direccion") );

            Proveedor proveedor = new Proveedor(nombre,ubicacion1,contacto);

            proveedores.add(proveedor);
        }

        datos.put("Proveedores: ",proveedores);
        return datos;
    }

    public HashMap<String,Object> obtenerProducto(String nombre) {
        HashMap<String,Object> datos = new HashMap<>();
        //Producto alumno = new Producto();
        /** aquí se deben tomar los valores del map para armar el json (opcional) **/
        String json = "{ nombre : { $eq : \"" + nombre + "\" } }";
        Document filtro = Document.parse(json);
        FindIterable resultado = coleccion.find(filtro);
        MongoCursor iterador = resultado.iterator();

        while (iterador.hasNext()){
            Document documento = (Document) iterador.next();
            //String nombre = documento.getString("nombre");
            datos.put("nombre",nombre);
            datos.put("descripcion",documento.getString("descripcion"));
            datos.put("categoria",documento.getString("categoria"));
            datos.put("precioCompra",documento.getDouble("precioCompra"));
            datos.put("precioVenta",documento.getDouble("precioVenta"));
            datos.put("stock",documento.getInteger("stock"));
            datos.put("stockMinimo",documento.getInteger("stockReposicion"));
            datos.put("nombreProveedor",documento.getString("nombreProveedor"));
        }

        return datos;
    }

    public void insertDocumento(HashMap<String,Object> elementoAgregar,String coleccion){
        this.conectar("inventario",coleccion);
        Document nuevoDocumento = new Document();
        for(String campo : elementoAgregar.keySet() ){
            nuevoDocumento.append(campo,elementoAgregar.get(campo));
        }

        this.coleccion.insertOne(nuevoDocumento);
    }

    public void insertProducto(HashMap<String,Object> elementoAgregar){
        this.conectar("inventario","producto");
        Document nuevoDocumento = new Document();
        for (String campo : elementoAgregar.keySet()){
            if (campo == "stock" || campo == "stockDeReposicion"){
                nuevoDocumento.append(campo,"NumberInt(" + elementoAgregar.get(campo) + ")");
            }
            else{
                nuevoDocumento.append(campo,elementoAgregar.get(campo));
            }
        }
    }

    public void actualizarDocumento(int id,String campo,Object nuevoValor,String coleccion){
        this.conectar("inventario",coleccion);
        String json = "{ id : { $eq :" + id +" } }";
        Document filtro = Document.parse(json);
        json = "{ $set: { " + campo + ":   " + nuevoValor + " } }";
        Document nuevosValores= Document.parse(json);
        this.coleccion.updateOne(filtro,nuevosValores);
    }

    public void eliminarDocumento(int id,String coleccion){
        this.conectar("inventario",coleccion);
        String json = "{ id: { $eq: " + "\"" + id + "\"" + "} }";
        Document filtro = Document.parse(json);
        this.coleccion.deleteOne(filtro);
    }

    public static void main(String[] args) {
        MongoDB mongo = new MongoDB("producto");
        mongo.obtenerDatosProducto();
    }
    /**
     * documentación de clase Document
     * http://mongodb.github.io/mongo-java-driver/3.6/javadoc/org/bson/Document.html
     */

}
