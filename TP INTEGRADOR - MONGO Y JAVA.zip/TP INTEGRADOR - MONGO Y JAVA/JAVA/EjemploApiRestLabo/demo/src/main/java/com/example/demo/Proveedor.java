package com.example.demo;

import java.util.HashMap;
import java.util.HashSet;

public class Proveedor {
    private String nombre;
    private Ubicacion ubicacion;
    private int contacto;
    private HashSet<HashMap<String,Integer>> listaProductos;

    public Proveedor(String nombre, Ubicacion ubicacion, int contacto, HashSet<HashMap<String, Integer>> listaProductos) {
        this.nombre = nombre;
        this.ubicacion = ubicacion;
        this.contacto = contacto;
        this.listaProductos = listaProductos;
    }

    public Proveedor(String nombre, Ubicacion ubicacion, int contacto) {
        this.nombre = nombre;
        this.ubicacion = ubicacion;
        this.contacto = contacto;
        this.listaProductos = new HashSet<>();
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public Ubicacion getUbicacion() {
        return ubicacion;
    }

    public void setUbicacion(Ubicacion ubicacion) {
        this.ubicacion = ubicacion;
    }

    public int getContacto() {
        return contacto;
    }

    public void setContacto(int contacto) {
        this.contacto = contacto;
    }

    public HashSet<HashMap<String, Integer>> getListaProductos() {
        return listaProductos;
    }

    public void setListaProductos(HashSet<HashMap<String, Integer>> listaProductos) {
        this.listaProductos = listaProductos;
    }
}

