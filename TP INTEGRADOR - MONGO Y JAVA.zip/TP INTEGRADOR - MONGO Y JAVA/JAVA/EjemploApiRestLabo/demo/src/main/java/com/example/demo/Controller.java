package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.*;

/** url: http://localhost:8080/api/... **/

@RestController
@RequestMapping("/api")
@CrossOrigin(origins = "*", allowedHeaders = "*")
public class Controller {

    @Autowired
    private MongoDB accesoABaseDeDatos;

    public Controller() {
        this.accesoABaseDeDatos = new MongoDB();
    }

    //GET MANY

    @RequestMapping(value = "/datos/productos", method = RequestMethod.GET)
    public ResponseEntity<Object> obtenerProductos() {
        HashMap<String, Object> datos = accesoABaseDeDatos.obtenerDatosProducto();
        return new ResponseEntity<>(datos, HttpStatus.OK);
    }

    @RequestMapping(value = "/datos/proveedores", method = RequestMethod.GET)
    public ResponseEntity<Object> obtenerProveedores() {
        HashMap<String, Object> datos = accesoABaseDeDatos.obtenerDatosProducto();
        return new ResponseEntity<>(datos, HttpStatus.OK);
    }

    @RequestMapping(value = "/datos/compras", method = RequestMethod.GET)
    public ResponseEntity<Object> obtenerCompras() {
        HashMap<String, Object> datos = accesoABaseDeDatos.obtenerDatosProducto();
        return new ResponseEntity<>(datos, HttpStatus.OK);
    }

    @RequestMapping(value = "/datos/productos/{nombre}", method = RequestMethod.GET)
    public ResponseEntity<Object> agregarProducto(@PathVariable String nombre) {
        HashMap<String,Object> datos = accesoABaseDeDatos.obtenerProducto(nombre);
        return new ResponseEntity<>(datos,HttpStatus.OK);
    }

    //INSERT

    @RequestMapping(value = "/datos/productos", method = RequestMethod.POST)
    public ResponseEntity<Object> agregarProducto(@RequestBody HashMap producto) {
        accesoABaseDeDatos.insertProducto(producto);
        return new ResponseEntity<>(HttpStatus.OK);
    }

    @RequestMapping(value = "/datos/proveedores", method = RequestMethod.POST)
    public ResponseEntity<Object> agregarProveedor(@RequestBody HashMap proveedor) {
        accesoABaseDeDatos.insertDocumento(proveedor,"producto");
        return new ResponseEntity<>(HttpStatus.OK);
    }

    //UPDATE
/*
    @RequestMapping(value = "/datos/productos/{id}", method = RequestMethod.PATCH)
    public ResponseEntity<Object> modificarProducto(@PathVariable int id,@RequestBody HashMap nuevosDatos) {
        String campo = (String) nuevosDatos.get("campo");
        Object valor = nuevosDatos.get("valor");
        accesoABaseDeDatos.actualizarDocumento(id,campo,valor,"producto");
        return new ResponseEntity<>(HttpStatus.OK);
    }

    @RequestMapping(value = "/datos/productos/{id}", method = RequestMethod.PATCH)
    public ResponseEntity<Object> modificarProveedor(@PathVariable int id,@RequestBody HashMap nuevosDatos) {
        String campo = (String) nuevosDatos.get("campo");
        Object valor = nuevosDatos.get("valor");
        accesoABaseDeDatos.actualizarDocumento(id,campo,valor,"proveedor");
        return new ResponseEntity<>(HttpStatus.OK);
    }

    @RequestMapping(value = "/datos/productos/{id}", method = RequestMethod.PATCH)
    public ResponseEntity<Object> modificarCompra(@PathVariable int id,@RequestBody HashMap nuevosDatos) {
        String campo = (String) nuevosDatos.get("campo");
        Object valor = nuevosDatos.get("valor");
        accesoABaseDeDatos.actualizarDocumento(id,campo,valor,"compra");
        return new ResponseEntity<>(HttpStatus.OK);
    }

    //DELETE

    @RequestMapping(value = "/datos/productos/{id}", method = RequestMethod.DELETE)
    public ResponseEntity<Object> borrarProducto(@PathVariable int id) {
        accesoABaseDeDatos.eliminarDocumento(id,"producto");
        return new ResponseEntity<>(HttpStatus.OK);
    }

    @RequestMapping(value = "/datos/productos/{id}", method = RequestMethod.DELETE)
    public ResponseEntity<Object> borrarProveedor(@PathVariable int id) {
        accesoABaseDeDatos.eliminarDocumento(id,"proveedor");
        return new ResponseEntity<>(HttpStatus.OK);
    }

    @RequestMapping(value = "/datos/productos/{id}", method = RequestMethod.DELETE)
    public ResponseEntity<Object> borrarCompra(@PathVariable int id) {
        accesoABaseDeDatos.eliminarDocumento(id,"compra");
        return new ResponseEntity<>(HttpStatus.OK);
    }
*/

}

